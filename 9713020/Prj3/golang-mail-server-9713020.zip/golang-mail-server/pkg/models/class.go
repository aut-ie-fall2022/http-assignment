package models

type Class struct {
	Model
	Field   string
	Teacher string
}
