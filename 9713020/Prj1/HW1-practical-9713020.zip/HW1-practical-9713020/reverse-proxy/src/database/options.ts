export const DEFAULT_HAS_MANY_OPTIONS = {
  onDelete: "cascade",
};

export const DEFAULT_BELONGS_TO_OPTIONS = {
  onDelete: "cascade",
};
