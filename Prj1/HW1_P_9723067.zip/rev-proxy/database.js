const users = [
    {
        id: 1,
        username: "admin",
        password: "admin",
        isAdmin: true,
        token: null,
    },
    {
        id: 2,
        username: "sajad",
        password: "12345",
        isAdmin: false,
        token: null,
    }
]


module.exports = {
    users
}
