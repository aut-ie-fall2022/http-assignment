module.exports = {
    JWT:{
        secret: "SajadGG"
    }
}
