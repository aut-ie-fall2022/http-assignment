const verify = require("jsonwebtoken").verify
const Config = require("./config")
const users = require("./database").users


const auth = (req, res, next) => {
    const [bearer, token] = String(req.headers["authorization"])
        .split(" ")
    if (bearer !== "Bearer") {
        res.send(`Token format must be like: "Bearer TOKEN"`)
    }
    try {
        const decoded = verify(token, Config.JWT.secret)
        req.user = decoded
        let foundUser = null
        for (let user of users) {
            if (decoded.username === user.username) {
                foundUser = user
                break
            }
        }
        if (!foundUser) {
            return res.send("Invalid token! User not found!")
        }
        if (!foundUser.token || foundUser.token !== token) {
            console.log(foundUser.token,token)
            return res.send("Token mismatch!")
        }
    } catch (e) {
        return res.send("Invalid token!")
    }
    next()
}


module.exports = {
    auth
}