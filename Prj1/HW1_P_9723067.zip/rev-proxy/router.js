const users = require("./database").users
const auth = require("./jwt").auth
const sign = require("jsonwebtoken").sign
const Config = require("./config")
const httpProxy = require('http-proxy');

const proxy = httpProxy.createProxyServer();


const Router = (app) => {
    app.all("/", (req, res) => res.send("Home!"))
    app.post("/login", (req, res) => {
        const loginData = req.body
        if (!loginData.username || !loginData.password) {
            return res.send("Invalid request!")
        }

        let foundUser = null
        for (let user of users) {
            if (loginData.username === user.username) {
                foundUser = user
                break
            }
        }

        if (!foundUser) {
            return res.send("User not found!")
        }

        if (foundUser.password !== loginData.password) {
            return res.send("Invalid password!")
        }
        const {id, username, isAdmin} = foundUser
        const token = sign(
            {id, username, isAdmin},
            Config.JWT.secret,
            {
                expiresIn: "2h",
            });
        foundUser.token = token
        res.json({
            token
        })
    })

    app
        .use("/logout", auth)
        .post("/logout", (req, res) => {
            const username = req.user.username
            let foundUser = null
            for (let user of users) {
                if (username === user.username) {
                    foundUser = user
                    break
                }
            }
            if (!foundUser) {
                return res.send("User not found!")
            }
            foundUser.token = null
            res.send("Logout successful!")
        })

    app
        .use("/users", auth)
        .get("/users", (req, res) => {
            const isAdmin = req.user.isAdmin

            if (!isAdmin) {
                res.send("Only admins can see user data!")
            }
            res.json(users)
        })


    app.use("*", auth)
        .all('*', (req, res) => {
            const target = String(req.headers["x-target"])
            proxy.web(req, res, {target: target})
        })
}


module.exports = Router