# Reverse proxy HW-9723067

This is a simple reverse proxy for web class.

## How to run the program

- Build the image: (Just for the first time!)
```shell
# in linux
docker build -t rev-proxy .
# in windows 
docker build -t rev-proxy ./
```
- Run the container:(Each time)

```shell
docker run -d --rm -p 3000:3000 --name rev-proxy-app  rev-proxy
```


- Stop the container:

```shell
docker stop rev-proxy-app
```

- To see the API endpoints open api-document.yaml in insomnia or postman.