from http.server import HTTPServer, BaseHTTPRequestHandler
import jwt
import requests
from socketserver import ThreadingMixIn

'''reference : https://github.com/MollardMichael/python-reverse-proxy/blob/master/proxy.py'''

PORT = 7854
HOST = "localhost"


def set_header():
    headers = {
        'Host': HOST
    }

    return headers


def merge_two_dicts(x, y):
    return {**x, **y}


class HTTP_PROXY(BaseHTTPRequestHandler):

    def do_GET(self, body=True):
        sent = False
        try:
            # url of main server and target (main server) is httpbin.org
            url = 'https://{}{}'.format('httpbin.org/', self.path)

            #parse header
            req_header = {}
            for line in self.headers:
                line_parts = [o.strip() for o in line.split(':', 2)]
                if len(line_parts) == 2:
                    req_header[line_parts[0]] = line_parts[1]


            # jwt header and jwt token
            s = self.headers.values()[0].split()
            token = s[1]

            header_data = jwt.get_unverified_header(token)

            from jwt.exceptions import ExpiredSignatureError
            try:
                payload = jwt.decode(token, key='pouria_jwt', algorithms=[header_data['alg'], ])
                print("data is  :  ")
                print(payload)

            except ExpiredSignatureError:
                self.send_error(401, 'error trying to proxy')

            resp = requests.get(url, headers=merge_two_dicts(req_header, set_header()), verify=False)
            sent = True

            self.send_response(resp.status_code)
            respheaders = resp.headers
            print('Response Header')
            for key in respheaders:
                if key not in ['Content-Encoding', 'Transfer-Encoding', 'content-encoding', 'transfer-encoding',
                               'content-length', 'Content-Length']:
                    print(key, respheaders[key])
                    self.send_header(key, respheaders[key])
            self.send_header('Content-Length', len(resp.content))
            self.end_headers()
            message = resp.text
            if body:
                print("well done !!")
                self.wfile.write(message.encode(encoding='UTF-8', errors='strict'))

            return
        finally:
            if not sent:
                self.send_error(404, 'error trying to proxy')

    def jwt_token(self):
        s = self.headers.values()[0].split()
        return s[1]

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""


if __name__ == '__main__':
    httpd = ThreadedHTTPServer((HOST, PORT), HTTP_PROXY)
    print('http server is running as reverse proxy')
    httpd.serve_forever()
    httpd.server_close()
#
