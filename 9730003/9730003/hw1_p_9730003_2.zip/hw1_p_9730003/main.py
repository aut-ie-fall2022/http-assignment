#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
import argparse, os, random, sys, requests
import jwt

from socketserver import ThreadingMixIn
import threading

hostname = 'httpbin.org'


def merge_two_dicts(x, y):
    return x | y


def set_header():
    headers = {
        'Host': hostname
    }

    return headers


class ProxyHTTPRequestHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.0'

    def do_HEAD(self):
        self.do_GET(body=False)
        return


    def do_GET(self, body=True):
        sent = False
        try:
            url = 'https://{}{}'.format(hostname, self.path)
            req_header,ok = self.parse_headers()

            if not ok:
                return

            print("req_header: ",req_header)
            print("url: ",url)
            resp = requests.get(url, headers=merge_two_dicts(req_header, set_header()), verify=False)
            print("resp",resp)
            sent = True

            self.send_response(resp.status_code)
            self.send_resp_headers(resp)
            msg = resp.text
            if body:
                self.wfile.write(msg.encode(encoding='UTF-8', errors='strict'))
            return
        finally:
            if not sent:
                self.send_error(404, 'error trying to proxy')

    def do_POST(self, body=True):
        sent = False
        try:
            url = 'https://{}{}'.format(hostname, self.path)
            content_len = int(self.headers.getheader('content-length', 0))
            post_body = self.rfile.read(content_len)
            req_header,ok = self.parse_headers()

            if not ok:
                return

            resp = requests.post(url, data=post_body, headers=merge_two_dicts(req_header, set_header()), verify=False)
            sent = True

            self.send_response(resp.status_code)
            self.send_resp_headers(resp)
            if body:
                self.wfile.write(resp.content)
            return
        finally:
            if not sent:
                self.send_error(404, 'error trying to proxy')

    def parse_headers(self):
        req_header = {}
        s = str(self.headers)

        for line in s.split("\n"):
            line_parts = [o.strip() for o in line.split(':', 1)]
            if len(line_parts) == 2:
                req_header[line_parts[0]] = line_parts[1]

        print(req_header)
        aut = req_header.get("Authorization").split(" ")[1].replace(" ","")
        print("aut==>",aut)

        try:
            enable = jwt.decode(aut, key='tuf', algorithms=['HS256'])
            print(enable)
            ok = True
        except:
            print("jwt is incorrect")
            self.send_error(401, 'error trying to proxy(jwt error)')
            ok = False


        return req_header,ok

    def send_resp_headers(self, resp):
        respheaders = resp.headers
        print('Response Header')
        for key in respheaders:
            if key not in ['Content-Encoding', 'Transfer-Encoding', 'content-encoding', 'transfer-encoding',
                           'content-length', 'Content-Length']:
                print(key, respheaders[key])
                self.send_header(key, respheaders[key])
        self.send_header('Content-Length', len(resp.content))
        self.end_headers()




class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""


def main():
    global hostname
    #args = parse_args(argv)
    hostname = "httpbin.org"
    print('http server is starting on {} port {}...'.format(hostname, 80))
    server_address = ('127.0.0.1', 8081)
    httpd = ThreadedHTTPServer(server_address, ProxyHTTPRequestHandler)
    print('http server is running as reverse proxy')
    httpd.serve_forever()


if __name__ == '__main__':
    #token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY0NTc4OTAiLCJuYW1lIjoiYW1pcmJhIiwiaWF0IjoxNTE2MjM5MDIyfQ.XqA8NhV3yPzVHTakCOybgYy7r9XRISSAtUMKeunksCE'
    #en = jwt.decode(token, key='salam', algorithms=['HS256' ])
    #print(en)
    main()
